package game;

public class MoleArmy {
	
	String name;
	int att;
	String[] weapons;
	

	public MoleArmy(String name, int att, String[] weapons) {
	this.name = name;
	this.att = att;
	this.weapons = weapons;
	}
}
